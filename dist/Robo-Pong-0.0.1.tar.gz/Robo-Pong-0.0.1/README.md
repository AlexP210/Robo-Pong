# Rover
A project to learn about IoT, computer vision and robotics by building a WiFi-controlled rover 